from PyQt5.QtWidgets import QApplication, QMainWindow, QPushButton, QVBoxLayout, QWidget, QLabel, QTextEdit, QLineEdit
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QDropEvent
from textblob import TextBlob
import mysql.connector
from functools import lru_cache
from dataclasses import dataclass
from PyPDF2 import PdfFileReader
from pdfminer.high_level import extract_pages
from pdfminer.layout import LTTextContainer
from docx import Document
import os
from google_play_scraper import Sort, reviews, app
from collections import defaultdict
import matplotlib.pyplot as plt
import speech_recognition as sr
import configparser
from PyQt5.QtWidgets import QLabel, QVBoxLayout, QFrame, QSizePolicy
from PyQt5.QtGui import QFont, QColor
from PyQt5.QtCore import Qt

# Read database credentials from config.ini
config = configparser.ConfigParser()
config.read('config.ini')

DB_HOST = config['database']['host']
DB_USER = config['database']['user']
DB_PASS = config['database']['password']
DB_NAME = config['database']['dbname']


@lru_cache(maxsize=None)
@dataclass
class Mood:
    emoji: str
    sentiment: float
    sentiment_name: str

def create_connection():
    return mysql.connector.connect(
        host=DB_HOST,
        user=DB_USER,
        password=DB_PASS,
        database=DB_NAME
    )

def fetch_sentiments():
    conn = None
    try:
        conn = create_connection()

        if conn.is_connected():
            cursor = conn.cursor()

            cursor.execute("SELECT * FROM python_sentiments.sentiments")  # replace with your table and column name
            sentiments = cursor.fetchall()
            return [item[0] for item in sentiments]
        else:
            print("Failed to connect to the database")

    except mysql.connector.Error as e:
        print(f"Error: {e}")
    finally:
        if conn.is_connected():
            conn.close()
            print("Database connection closed")


def get_mood(input_text: str, sentiments: list, *, threshold: float) -> Mood:
    blob = TextBlob(input_text)
    sentiment = blob.sentiment.polarity

    sentiment_emojis = {
        'Happy': '😊',
        'Sad': '😟',
        'Neutral': '😐',
        'Excited': '😃',
        'Angry': '😠'
    }

    excitement_keywords = ['excited', "can't wait", 'eager', 'thrilled', 'wow', 'amazing',
                           'fantastic', 'incredible', 'astonishing', 'impressive',
                           'awesome', 'stoked', 'ecstatic', 'enthusiastic', 'animated',
                           'lively', 'spirited', 'exhilarated']

    anger_keywords = ['angry', 'mad', 'furious', 'livid',
                      'irate', 'annoyed', 'aggravated',
                      'frustrated', 'enraged', 'indignant',
                      'outraged', 'exasperated']

    happy_keywords = ['happy', 'joyful', 'lovely', 'love'
                      'pleased',
                      'contented',
                      'cheerful',
                      'merry',
                      'elated',
                      'satisfied',
                      'radiant',
                      'blissful']

    sad_keywords = ['sad',
                    'unhappy',
                    'sorrowful',
                    'dejected',
                    'regretful',
                    'depressed',
                    'downcast',
                    'miserable',
                    'downhearted',
                    'despondent']

    is_excited = any(keyword in input_text.lower() for keyword in excitement_keywords)
    is_angry = any(keyword in input_text.lower() for keyword in anger_keywords)
    is_happy = any(keyword in input_text.lower() for keyword in happy_keywords)
    is_sad = any(keyword in input_text.lower() for keyword in sad_keywords)

    if sentiment > 0:  # sentiment is positive
        if is_excited:
            return Mood(sentiment_emojis['Excited'], sentiment, 'Excited')
        else:
            return Mood(sentiment_emojis['Happy'], sentiment, 'Happy')
    elif sentiment < 0:  # sentiment is negative
        if is_angry:
            return Mood(sentiment_emojis['Angry'], sentiment, 'Angry')
        else:
            return Mood(sentiment_emojis['Sad'], sentiment, 'Sad')
    else:  # sentiment is neutral
        if is_happy:
            return Mood(sentiment_emojis['Happy'], sentiment, 'Happy')
        elif is_sad:
            return Mood(sentiment_emojis['Sad'], sentiment, 'Sad')
        else:
            return Mood(sentiment_emojis['Neutral'], sentiment, 'Neutral')

class TextEditWithDrop(QTextEdit):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.setAcceptDrops(True)

    def dropEvent(self, event: QDropEvent):
        if event.mimeData().hasUrls():
            url = event.mimeData().urls()[0]
            file_path = url.toLocalFile()
            if os.path.isfile(file_path):
                if file_path.endswith('.txt'):
                    with open(file_path, 'r') as f:
                        self.setText(f.read(10000))  # read only first 10000 characters
                elif file_path.endswith('.pdf'):
                    text = ''
                    for page_layout in extract_pages(file_path):
                        for element in page_layout:
                            if isinstance(element, LTTextContainer):
                                text += element.get_text()
                    self.setText(text[:10000])  # read only first 10000 characters
                elif file_path.endswith('.docx'):
                    doc = Document(file_path)
                    text = ' '.join([paragraph.text for paragraph in doc.paragraphs])
                    self.setText(text[:10000])  # read only first 10000 characters

class MainWindow(QMainWindow):
    def __init__(self):
        super(MainWindow, self).__init__()

        # Set window title and size
        self.setWindowTitle('Sentiment Analysis App')
        self.setGeometry(100, 100, 800, 600)

        # Set the font
        font = QFont()
        font.setFamily('Arial')
        font.setPointSize(12)
        self.setFont(font)

        # Set the window's layout
        layout = QVBoxLayout()

        # Create a frame for the title
        title_frame = QFrame()
        title_frame.setFrameShape(QFrame.StyledPanel)
        title_frame.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

        # Create a label for the title
        title_label = QLabel('Sentiment Analysis', title_frame)
        title_label.setFont(QFont('Arial', 24))
        title_label.setAlignment(Qt.AlignCenter)

        layout.addWidget(title_frame)

        self.text_entry = TextEditWithDrop()
        self.analyze_button = QPushButton("Analyze")
        self.clear_button = QPushButton("Clear")
        self.result_label = QTextEdit()
        self.result_label.setReadOnly(True)
        self.result_label.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
        self.result_label.hide()

        self.analyze_button.clicked.connect(self.analyze_sentiment)
        self.clear_button.clicked.connect(self.clear_text)

        layout = QVBoxLayout()
        layout.addWidget(self.text_entry)
        layout.addWidget(self.analyze_button)
        layout.addWidget(self.clear_button)
        layout.addWidget(self.result_label)

        container = QWidget()
        container.setLayout(layout)

        self.setCentralWidget(container)

        self.package_name_input = QLineEdit()
        self.fetch_reviews_button = QPushButton("Fetch Reviews")

        self.fetch_reviews_button.clicked.connect(self.fetch_and_add_reviews)

        layout = QVBoxLayout()
        layout.addWidget(self.text_entry)
        layout.addWidget(self.package_name_input)
        layout.addWidget(self.fetch_reviews_button)
        layout.addWidget(self.analyze_button)
        layout.addWidget(self.clear_button)
        layout.addWidget(self.result_label)

        container = QWidget()
        container.setLayout(layout)

        self.setCentralWidget(container)
        self.plot_button = QPushButton("Plot Sentiment Counts")
        self.plot_button.clicked.connect(self.plot_sentiment_counts)
        layout.addWidget(self.plot_button)

        self.voice_input_button = QPushButton("Voice Input")
        self.voice_input_button.clicked.connect(self.voice_to_text)
        layout.addWidget(self.voice_input_button)

        # Set the layout to the central widget of your QMainWindow
        central_widget = QWidget()
        central_widget.setLayout(layout)
        self.setCentralWidget(central_widget)

    def plot_sentiment_counts(self):
        sentiment_counts = fetch_sentiment_counts()

        sentiments = [row[0] for row in sentiment_counts]
        counts = [row[1] for row in sentiment_counts]

        plt.figure(facecolor='black')
        plt.bar(sentiments, counts, color=['red', 'green', 'blue', 'yellow', 'purple'])
        plt.title('Sentiment Counts', color='white')
        plt.xlabel('Sentiment', color='white')
        plt.ylabel('Count', color='white')
        plt.tick_params(colors='white')

        plt.show()

    def closeEvent(self, event):
        clear_sentiment_counts()
        event.accept()

    def fetch_and_add_reviews(self):
        package_name = self.package_name_input.text()
        if package_name:
            try:
                reviews_list = fetch_reviews(package_name)
                if reviews_list:
                    self.add_reviews_to_textbox(reviews_list)
                else:
                    self.text_entry.setPlainText("No reviews found.")
            except Exception as e:
                self.text_entry.setPlainText(f"Error: {str(e)}")
        else:
            self.text_entry.setPlainText("Please enter a Google Play package name.")

    def add_reviews_to_textbox(self, reviews):
        for review in reviews:
            self.text_entry.append(review)


    def clear_text(self):
        self.text_entry.clear()

    def analyze_sentiment(self):
        text = self.text_entry.toPlainText().strip()
        sentiments = fetch_sentiments()

        comments = text.split('\n')

        sentiment_counts = {'Happy': 0, 'Sad': 0, 'Neutral': 0, 'Excited': 0, 'Angry': 0}

        for comment in comments:
            mood = get_mood(comment, sentiments, threshold=0.1)
            sentiment_counts[mood.sentiment_name] += 1

        for sentiment, count in sentiment_counts.items():
            update_sentiment_count(sentiment, count)

        positive_comments = defaultdict(list)
        negative_comments = defaultdict(list)
        neutral_comments = []

        for comment in comments:
            mood = get_mood(comment, sentiments, threshold=0.1)

            if mood.sentiment_name == 'Happy' or mood.sentiment_name == 'Excited':
                positive_comments[mood.sentiment_name].append(f'{mood.emoji} {comment} ({mood.sentiment:.2f})')
            elif mood.sentiment_name == 'Sad' or mood.sentiment_name == "Angry":
                negative_comments[mood.sentiment_name].append(f'{mood.emoji} {comment} ({mood.sentiment:.2f})')
            else:
                neutral_comments.append(f'{mood.emoji} {comment} ({mood.sentiment:.2f})')

        result_text = ""

        if positive_comments:
            result_text += "Positive Comments:\n"
            for category, comments in positive_comments.items():
                result_text += f"{category}:\n"
                result_text += "\n".join(comments) + "\n"

        if negative_comments:
            result_text += "\nNegative Comments:\n"
            for category, comments in negative_comments.items():
                result_text += f"{category}:\n"
                result_text += "\n".join(comments) + "\n"

        if neutral_comments:
            result_text += "\nNeutral Comments:\n"
            result_text += "\n".join(neutral_comments) + "\n"

        self.result_label.setPlainText(result_text)
        self.result_label.show()

    def voice_to_text(self):
        recognizer = sr.Recognizer()
        with sr.Microphone() as source:
            self.text_entry.setPlainText("Listening...")
            QApplication.processEvents()  # Refresh the GUI
            audio_data = recognizer.listen(source)
            try:
                text = recognizer.recognize_google(audio_data)
                self.text_entry.setPlainText(text)
            except sr.UnknownValueError:
                self.text_entry.setPlainText("Sorry, I did not get that!")
            except sr.RequestError:
                self.text_entry.setPlainText(
                    "API unavailable. Please try again later.")

def update_sentiment_count(sentiment, count):
    conn = None
    try:
        conn = create_connection()

        if conn.is_connected():
            cursor = conn.cursor()
            update_query = """
            UPDATE python_sentiments.sentiments
            SET sentiment_count = sentiment_count + %s
            WHERE sentiment = %s
            """
            cursor.execute(update_query, (count, sentiment))
            conn.commit()
    except mysql.connector.Error as e:
        print(f"Error: {e}")
    finally:
        if conn.is_connected():
            conn.close()

def clear_sentiment_counts():
    conn = None
    try:
        conn = create_connection()

        if conn.is_connected():
            cursor = conn.cursor()
            update_query = """
            UPDATE python_sentiments.sentiments
            SET sentiment_count = 0
            """
            cursor.execute(update_query)
            conn.commit()
    except mysql.connector.Error as e:
        print(f"Error: {e}")
    finally:
        if conn.is_connected():
            conn.close()

def fetch_sentiment_counts():
    conn = None
    try:
        conn = create_connection()

        if conn.is_connected():
            cursor = conn.cursor()
            cursor.execute("SELECT sentiment, sentiment_count FROM python_sentiments.sentiments")
            return cursor.fetchall()
    except mysql.connector.Error as e:
        print(f"Error: {e}")
    finally:
        if conn.is_connected():
            conn.close()

sentiment_counts = fetch_sentiment_counts()

sentiments = [row[0] for row in sentiment_counts]
counts = [row[1] for row in sentiment_counts]

plt.figure(facecolor='black')
plt.bar(sentiments, counts, color=['red', 'green', 'blue', 'yellow', 'purple'])
plt.title('Sentiment Counts', color='white')
plt.xlabel('Sentiment', color='white')
plt.ylabel('Count', color='white')
plt.tick_params(colors='white')

plt.show()

stylesheet = """
   QMainWindow {
        background-color: #333;
    }

    QTextEdit {
        background-color: #222;
        color: #fff;
        border: 2px solid #555;
        border-radius: 10px;
    }

    QPushButton {
        background-color: #5f5;
        color: #000;
        border: none;
        border-radius: 10px;
        padding: 5px 10px;
    }

    QPushButton:hover {
        background-color: #8f8;
    }

    QLabel {
        color: #fff;
    }
"""

def fetch_reviews(app_id: str, count: int = 1000):
    result, _ = reviews(
        app_id,
        lang='en',
        sort=Sort.MOST_RELEVANT,
        count=count
    )
    return [review['content'] for review in result]

if __name__ == '__main__':
    app = QApplication([])
    app.setStyleSheet(stylesheet)  # Apply the stylesheet
    window = MainWindow()
    window.show()
    app.exec_()
